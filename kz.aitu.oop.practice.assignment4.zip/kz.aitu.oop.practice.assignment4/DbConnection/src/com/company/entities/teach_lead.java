package com.company.entities;

public class teach_lead extends Commands {
    private int teach_lead_id;
    private String task;
    private String level;
    private int experience;

    public teach_lead() {

    }

    public teach_lead(int teach_lead_id) {
        setTeach_lead_id(teach_lead_id);
    }

    public  teach_lead(int teach_lead_id, String task, String level, int experience) {
        setTeach_lead_id(teach_lead_id);
        setTask(task);
        setLevel(level);
        setExperience(experience);
    }

    public int getTeach_lead_id() {
        return teach_lead_id;
    }

    public void setTeach_lead_id(int teach_lead_id) {
        this.teach_lead_id = teach_lead_id;
    }

    public String getTask() {
        return task;
    }
    public void setTask(String task) {
        this.task = task;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public int getExperience() {
        return experience;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }

    @Override
    public String toString() {
        return "Company{" +
                "sa_id=" + teach_lead_id +
                ", task='" + task + '\'' +
                ", level='" + level + '\''+
                ", experience='" + experience + '\''+
                '}';
    }
}
