package com.company.entities;

public class Software_architect extends Commands {
    private int sa_id;
    private String task;
    private String level;
    private int experience;

    public Software_architect() {

    }

    public Software_architect(int sa_id) {
        setSa_id(sa_id);
    }

    public  Software_architect(int sa_id, String task, String level, int experience) {
        setSa_id(sa_id);
        setTask(task);
        setLevel(level);
        setExperience(experience);
    }

    public int getSa_id() {
        return sa_id;
    }

    public void setSa_id(int sa_id) {
        this.sa_id = sa_id;
    }

    public String getTask() {
        return task;
    }
    public void setTask(String task) {
        this.task = task;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public int getExperience() {
        return experience;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }

    @Override
    public String toString() {
        return "Company{" +
                "sa_id=" + sa_id +
                ", task='" + task + '\'' +
                ", level='" + level + '\''+
                ", experience='" + experience + '\''+
                '}';
    }
}
