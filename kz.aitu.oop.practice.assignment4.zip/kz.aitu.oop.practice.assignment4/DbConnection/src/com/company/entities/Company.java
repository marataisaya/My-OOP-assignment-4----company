package com.company.entities;

public class Company {
    private int id;
    private String name;
    private String leader;
    private int number_of_students;

    public Company() {

    }

    public Company(String name, String leader, int number_of_students) {
        setName(name);
        setLeader(leader);
        setNumber_of_students(number_of_students);
    }

    public Company(int id, String name, String leader, int number_of_students) {
        setId(id);
        setName(name);
        setLeader(leader);
        setNumber_of_students(number_of_students);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLeader() {
        return leader;
    }

    public void setLeader(String leader) {
        this.leader = leader;
    }

    public int getNumber_of_students() {
        return number_of_students;
    }

    public void setNumber_of_students(int number_of_students) {
        this.number_of_students = number_of_students;
    }

    @Override
    public String toString() {
        return "Company{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", leader='" + leader + '\'' +
                ", number_of_students='" + number_of_students + '\'' +
                '}';
    }
}
