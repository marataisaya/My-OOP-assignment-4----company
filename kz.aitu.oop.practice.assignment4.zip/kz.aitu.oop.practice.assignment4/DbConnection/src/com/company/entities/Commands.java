package com.company.entities;

public class Commands extends Company {
    private int command_id;
    private int id;

    public Commands() {

    }

    public Commands(int id) {
        setId(id);
    }

    public Commands(int command_id, int id) {
        setId(id);
        setCommand_id(id);
    }

    public int getCommand_id() {
        return command_id;
    }

    public void setCommand_id(int command_id) {
        this.command_id = command_id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    @Override
    public String toString() {
        return "Company{" +
                "command_id=" + command_id +
                ", id='" + id + '\'' +
                '}';
    }
}
