package com.company.entities;

public class Project_manager extends Commands {
    private int pm_id;
    private String task;
    private String level;
    private int experience;

    public Project_manager() {

    }

    public Project_manager(int pm_id) {
        setPm_id(pm_id);
    }

    public  Project_manager(int pm_id, String task, String level, int experience) {
        setPm_id(pm_id);
        setTask(task);
        setLevel(level);
        setExperience(experience);
    }

    public int getPm_id() {
        return pm_id;
    }

    public void setPm_id(int pm_id) {
        this.pm_id = pm_id;
    }

    public String getTask() {
        return task;
    }
    public void setTask(String task) {
        this.task = task;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public int getExperience() {
        return experience;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }

    @Override
    public String toString() {
        return "Company{" +
                "pm_id=" + pm_id +
                ", task='" + task + '\'' +
                ", level='" + level + '\''+
                ", experience='" + experience + '\''+
                '}';
    }
}
