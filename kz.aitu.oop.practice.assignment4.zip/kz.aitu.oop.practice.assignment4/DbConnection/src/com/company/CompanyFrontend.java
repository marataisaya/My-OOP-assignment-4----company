package com.company;

import com.company.controllers.CompanyController;
import com.company.repositories.interfaces.ICompanyRepository;

import java.sql.SQLException;
import java.util.Scanner;

public class CompanyFrontend {
    private final CompanyController controller;
    private final Scanner scanner;

    public CompanyFrontend(ICompanyRepository companyRepository) {
        controller = new CompanyController(companyRepository);
        scanner = new Scanner(System.in);
    }

    public void start() {
        while (true) {
            System.out.println();
            System.out.println("Welcome to Company");
            System.out.println("Select option:");
            System.out.println("1. Get all companies");
            System.out.println("2. Get company by id");
            System.out.println("3. Create company");
            System.out.println("0. Exit");
            System.out.println();
            try {
                System.out.print("Enter option (1-3): ");
                int option = scanner.nextInt();
                if (option == 1) {
                    getAllCompaniesMenu();
                } else if (option == 2) {
                    getCompanyByIdMenu();
                } else if (option == 3) {
                    createCompanyMenu();
                } else {
                    break;
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
                scanner.next(); // to ignore incorrect input
            }

            System.out.println("*************************");

        }
    }

    public void getAllCompaniesMenu() throws SQLException {
        String response = controller.getAllCompanies();
        System.out.println(response);
    }

    public void getCompanyByIdMenu() {
        System.out.println("Please enter id");

        int id = scanner.nextInt();
        String response = controller.getCompany(id);
        System.out.println(response);
    }

    public void createCompanyMenu() {
        System.out.println("Please enter name");
        String name = scanner.next();
        System.out.println("Please enter leader");
        String leader = scanner.next();
        System.out.println("Please enter number_of_students");
        int number_of_students = scanner.nextInt();

        String response = controller.createCompany(name, leader, number_of_students);
        System.out.println(response);
    }
}