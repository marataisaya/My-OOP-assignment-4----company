package com.company.controllers;

import com.company.entities.Company;
import com.company.repositories.interfaces.ICompanyRepository;

import java.sql.SQLException;
import java.util.List;

public class CompanyController {
    private final ICompanyRepository repo;

    public CompanyController(ICompanyRepository repo) {
        this.repo = repo;
    }

    public String createCompany(String name, String leader, int number_of_students) {

        Company company = new Company(name, leader , number_of_students);

        boolean created = repo.createCompany(company);

        return (created ? "Company was created!" : "Company creation was failed!");
    }
    public String getCompany(int id) {
        Company company = repo.getCompany(id);

        return (company == null ? "Company was not found!" : company.toString());
    }

    public String getAllCompanies() throws SQLException {
        List<Company> companies = repo.getAllCompanies();

        return companies.toString();
    }
}
