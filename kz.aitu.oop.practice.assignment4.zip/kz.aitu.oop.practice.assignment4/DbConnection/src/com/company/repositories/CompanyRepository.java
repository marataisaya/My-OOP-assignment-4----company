package com.company.repositories;

import com.company.data.interfaces.IDB;
import com.company.entities.Company;
import com.company.repositories.interfaces.ICompanyRepository;

import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class CompanyRepository implements ICompanyRepository {
    private final IDB db;

    public CompanyRepository(IDB db) {
        this.db = db;
    }

    @Override
    public boolean createCompany(Company company) {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "INSERT INTO company(name,leader,number_of_students) VALUES (?,?,?)";
            PreparedStatement st = con.prepareStatement(sql);

            st.setString(1, company.getName());
            st.setString(2, company.getLeader());
            st.setInt(3, company.getNumber_of_students());

            boolean executed = st.execute();
            return executed;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return false;
    }

    @Override
    public Company getCompany(int id) {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "SELECT id,name,leader,number_of_students FROM company WHERE id=?";
            PreparedStatement st = con.prepareStatement(sql);

            st.setInt(1, id);

            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                Company company = new Company(rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("leader"),
                        rs.getInt("number_of_students"));

                return company;
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return null;
    }

    @Override
    public List<Company> getAllCompanies() throws SQLException {
        String connectionUrl = "jdbc:postgresql://localhost:5432/Company";
        Connection con = DriverManager.getConnection(connectionUrl, "postgres", "9790");
        try {
            con = db.getConnection();
            String sql = "SELECT id,name,leader,number_of_students FROM company";
            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(sql);
            List<Company> companies = new ArrayList<>();
            while (rs.next()) {
                Company company = new Company(rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("leader"),
                        rs.getInt("number_of_students"));

                companies.add(company);
            }

            return companies;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return null;
    }
}